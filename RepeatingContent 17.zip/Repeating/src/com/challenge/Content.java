package com.challenge;

public class Content {
	public String value;
	public int age;

	@Override
	public String toString(){
		return "value: " + value + " age: " + age;
	}
}
