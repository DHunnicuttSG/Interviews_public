package com.challenge;

import java.io.*;
import java.util.ArrayList;

public class Repeating {
	public static void main(String[] args) {
		Repeating rp = new Repeating();
		
		rp.run();
	}
	
	public void run() {
		BufferedReader reader;
		ArrayList<Content> list = new ArrayList<Content>();
		Content content = new Content();
		
		try {
			System.out.println("*******************");
			System.out.println(content);
			System.out.println("*******************");

			String path = new File("./data").getCanonicalPath();
			reader = new BufferedReader(new FileReader(path +
					"/numbers.txt"));
			String data = reader.readLine();
			
			while (data != null) {
				content.value = data;
				list.add(content);
				data = reader.readLine();
			}
			
			for (int i=0 ; i < list.size(); i++) {
				System.out.println(list.get(i).value);
			}
			reader.close();
		}
		catch(IOException e) {
			e.printStackTrace();
		}
	}
}
